﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace WindowsFormsApp7
{
        public class human
    {
        public string name { set; get; }
        public string family { set; get; }
        public byte age { set; get; }

        public int codemeli
        {
            get => default(int);
            set
            {
            }
        }
    }
    class db : DbContext
    {
         public db():base("name=tt")
        {
        }
        public DbSet<human> humans { set; get; }
    }
}
