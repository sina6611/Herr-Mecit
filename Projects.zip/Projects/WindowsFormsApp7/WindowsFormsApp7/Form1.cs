﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        //    db db1 = new db();
           // dataGridView1.DataSource = db1.humans.ToList();
        }
       // List<human> humans = new List<human>();

        private void button1_Click(object sender, EventArgs e)
        {
            //if (Convert.ToByte(textBox3.Text) >= 18) { 
            //humans.Add(new human { name = textBox1.Text, family = textBox2.Text, age = Convert.ToByte(textBox3.Text) });
            //dataGridView1.DataSource = null;
            //dataGridView1.DataSource = humans;
            //}
            db db1 = new db();
            db1.humans.Add(new human { name = textBox1.Text, family = textBox2.Text, age = Convert.ToByte(textBox3.Text) });
            db1.SaveChanges();
        }
    }
}
